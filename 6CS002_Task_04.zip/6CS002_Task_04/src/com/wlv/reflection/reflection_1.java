package com.wlv.reflection;

public class reflection_1 {

  //creating an instance Simple and prints it out
	
  public static void main(String[] args) {
    Simple s = new Simple();
    System.out.println("s =" + s);
  }
}




